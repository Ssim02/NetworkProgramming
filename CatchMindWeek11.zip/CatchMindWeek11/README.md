# 캐치마인드 11주차

Java 21 · Eclipse · TCP 5000

1. ZIP을 풀고 Eclipse에서 **File → Import → General → Existing Projects into Workspace**를 선택한다.
2. `.project`가 있는 CatchMindWeek11 폴더를 선택한다.
3. `catchmind.server.TestServer`를 한 번 실행하고, `catchmind.client.ClientMain`을 두 번 실행한다.
4. 두 창에서 서버 주소 `127.0.0.1`을 사용하고 서로 다른 닉네임으로 접속한다.
5. 한쪽에서 색과 굵기를 바꿔 선을 그린 뒤 상대 화면에 반영되는지 확인한다. 전체 지우기와 채팅도 양쪽에서 확인한다.

5000번 포트가 이미 사용 중이면 Eclipse에서 기존 서버를 종료한 다음 다시 실행한다.

그림 통신 형식은 팀원 서버 브랜치 `dev-sjm`에 맞췄다.

- `/DRAW 1 x1 y1 x2 y2 RRGGBB 굵기`
- `/CLEAR 1`

라운드 번호는 현재 1이다. 내 동작은 내 화면에 먼저 반영하고, 서버는 다른 참가자에게 전달한다. 동시 그리기와 전체 지우기가 겹칠 때 모든 화면의 적용 순서를 일치시키는 처리와 새로 입장한 참가자에게 기존 그림을 보내는 기능은 이후 작업이다.
